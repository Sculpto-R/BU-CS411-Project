# events/views.py (root-level app)
from pathlib import Path
import csv

from django.conf import settings
from django.shortcuts import render

from .utils import get_coordinates  # we’ll create this next


def index(request):
    events = []

    # CSV is at: data_scripts/event_scraping/events_out.csv (from your tree)
    csv_path = Path(settings.BASE_DIR) / "data_scripts" / "event_scraping" / "events_out.csv"

    with csv_path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)

        for row in reader:
            # From your header:
            # event_id,source_url,source_site,venue_name,venue_url,event_title,category,tags,
            # start_local,end_local,timezone,start_utc,end_utc,city,address,latitude,longitude,...
            name = row.get("event_title") or "Untitled event"
            address = row.get("address") or ""
            date = row.get("start_local") or ""
            city = row.get("city") or ""

            # Prefer latitude/longitude from CSV
            lat = row.get("latitude")
            lng = row.get("longitude")

            try:
                lat = float(lat) if lat not in (None, "", "NaN") else None
                lng = float(lng) if lng not in (None, "", "NaN") else None
            except ValueError:
                lat, lng = None, None

            # Optional fallback to geocoding if coords missing
            if (lat is None or lng is None) and address:
                lat, lng = get_coordinates(address)

            # If still no coords, skip this event
            if lat is None or lng is None:
                continue

            events.append(
                {
                    "name": name,
                    "address": address or f"{row.get('venue_name', '')}, {city}",
                    "date": date,
                    "lat": lat,
                    "lng": lng,
                }
            )

    return render(request, "events/map.html", {"events": events})
